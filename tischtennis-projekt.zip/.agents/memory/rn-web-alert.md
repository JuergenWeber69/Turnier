---
name: react-native-web Alert.alert is broken
description: Why Expo apps deployed to web must not use Alert.alert for confirmations/notifications
---

On `Platform.OS === 'web'` (react-native-web), `Alert.alert(title, msg, [buttons])` does
NOT render a working dialog — button callbacks never fire. This silently breaks any
confirm/cancel flow when an Expo app is served as web (Replit publishes the tischtennis
artifact as a web build, and users open it in a desktop browser).

**Why:** A user got stuck on the finished-tournament screen because "Turnier beenden"
(reset) used Alert.alert; the destructive callback never ran on web.

**How to apply:** Route all dialogs through `artifacts/tischtennis/utils/dialog.ts`
(`confirmDialog` / `notify`), which use `window.confirm`/`window.alert` on web and fall
back to `Alert.alert` on native. Never call `Alert.alert` directly in screen code.
